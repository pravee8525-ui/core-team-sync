import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Project, Task, User } from '@/types';

interface ProjectState {
  projects: Project[];
  currentProject: Project | null;
  isLoading: boolean;
  createProject: (name: string, description: string, color: string) => void;
  deleteProject: (projectId: string) => void;
  updateProject: (projectId: string, updates: Partial<Project>) => void;
  setCurrentProject: (project: Project | null) => void;
  addProjectMember: (projectId: string, user: User, role: 'admin' | 'member') => void;
  removeProjectMember: (projectId: string, userId: string) => void;
  createTask: (projectId: string, task: Omit<Task, 'id' | 'projectId' | 'createdAt' | 'updatedAt'>) => void;
  updateTask: (taskId: string, updates: Partial<Task>) => void;
  deleteTask: (taskId: string) => void;
}

// Mock project data
const mockProjects: Project[] = [
  {
    id: '1',
    name: 'SynergySphere MVP',
    description: 'Building the core collaboration platform',
    color: '#3B82F6',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date(),
    members: [],
    tasks: [
      {
        id: '1',
        title: 'Design Authentication Flow',
        description: 'Create login and registration screens with proper validation',
        status: 'done',
        priority: 'high',
        projectId: '1',
        createdAt: new Date('2024-01-02'),
        updatedAt: new Date(),
        createdBy: '1',
      },
      {
        id: '2',
        title: 'Build Project Dashboard',
        description: 'Implement the main dashboard showing all projects',
        status: 'in-progress',
        priority: 'high',
        projectId: '1',
        createdAt: new Date('2024-01-03'),
        updatedAt: new Date(),
        createdBy: '1',
      },
      {
        id: '3',
        title: 'Implement Task Management',
        description: 'Create task boards with drag-and-drop functionality',
        status: 'todo',
        priority: 'medium',
        projectId: '1',
        createdAt: new Date('2024-01-04'),
        updatedAt: new Date(),
        createdBy: '1',
      },
    ],
  },
  {
    id: '2',
    name: 'Marketing Website',
    description: 'Build the public-facing marketing site',
    color: '#8B5CF6',
    createdAt: new Date('2024-01-05'),
    updatedAt: new Date(),
    members: [],
    tasks: [],
  },
];

export const useProjects = create<ProjectState>()(
  persist(
    (set, get) => ({
      projects: mockProjects,
      currentProject: null,
      isLoading: false,

      createProject: (name: string, description: string, color: string) => {
        const newProject: Project = {
          id: Date.now().toString(),
          name,
          description,
          color,
          createdAt: new Date(),
          updatedAt: new Date(),
          members: [],
          tasks: [],
        };
        
        set((state) => ({
          projects: [...state.projects, newProject],
        }));
      },

      deleteProject: (projectId: string) => {
        set((state) => ({
          projects: state.projects.filter(p => p.id !== projectId),
          currentProject: state.currentProject?.id === projectId ? null : state.currentProject,
        }));
      },

      updateProject: (projectId: string, updates: Partial<Project>) => {
        set((state) => ({
          projects: state.projects.map(p => 
            p.id === projectId ? { ...p, ...updates, updatedAt: new Date() } : p
          ),
          currentProject: state.currentProject?.id === projectId 
            ? { ...state.currentProject, ...updates, updatedAt: new Date() }
            : state.currentProject,
        }));
      },

      setCurrentProject: (project: Project | null) => {
        set({ currentProject: project });
      },

      addProjectMember: (projectId: string, user: User, role: 'admin' | 'member') => {
        set((state) => ({
          projects: state.projects.map(p => 
            p.id === projectId 
              ? {
                  ...p,
                  members: [...p.members, {
                    userId: user.id,
                    user,
                    role,
                    joinedAt: new Date(),
                  }],
                }
              : p
          ),
        }));
      },

      removeProjectMember: (projectId: string, userId: string) => {
        set((state) => ({
          projects: state.projects.map(p => 
            p.id === projectId 
              ? { ...p, members: p.members.filter(m => m.userId !== userId) }
              : p
          ),
        }));
      },

      createTask: (projectId: string, task: Omit<Task, 'id' | 'projectId' | 'createdAt' | 'updatedAt'>) => {
        const newTask: Task = {
          ...task,
          id: Date.now().toString(),
          projectId,
          createdAt: new Date(),
          updatedAt: new Date(),
        };

        set((state) => ({
          projects: state.projects.map(p => 
            p.id === projectId 
              ? { ...p, tasks: [...p.tasks, newTask] }
              : p
          ),
          currentProject: state.currentProject?.id === projectId
            ? { ...state.currentProject, tasks: [...state.currentProject.tasks, newTask] }
            : state.currentProject,
        }));
      },

      updateTask: (taskId: string, updates: Partial<Task>) => {
        set((state) => ({
          projects: state.projects.map(p => ({
            ...p,
            tasks: p.tasks.map(t => 
              t.id === taskId ? { ...t, ...updates, updatedAt: new Date() } : t
            ),
          })),
          currentProject: state.currentProject ? {
            ...state.currentProject,
            tasks: state.currentProject.tasks.map(t => 
              t.id === taskId ? { ...t, ...updates, updatedAt: new Date() } : t
            ),
          } : null,
        }));
      },

      deleteTask: (taskId: string) => {
        set((state) => ({
          projects: state.projects.map(p => ({
            ...p,
            tasks: p.tasks.filter(t => t.id !== taskId),
          })),
          currentProject: state.currentProject ? {
            ...state.currentProject,
            tasks: state.currentProject.tasks.filter(t => t.id !== taskId),
          } : null,
        }));
      },
    }),
    {
      name: 'projects-storage',
    }
  )
);