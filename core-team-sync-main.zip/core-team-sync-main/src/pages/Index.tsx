import React from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useProjects } from '@/hooks/useProjects';
import { AuthForm } from '@/components/auth/AuthForm';
import { Navigation } from '@/components/layout/Navigation';
import { ProjectDashboard } from '@/components/projects/ProjectDashboard';
import { ProjectDetailView } from '@/components/projects/ProjectDetailView';

const Index = () => {
  const { isAuthenticated } = useAuth();
  const { currentProject } = useProjects();

  if (!isAuthenticated) {
    return <AuthForm />;
  }

  return (
    <div className="min-h-screen bg-gradient-surface">
      <Navigation />
      {currentProject ? <ProjectDetailView /> : <ProjectDashboard />}
    </div>
  );
};

export default Index;
