import React from 'react';
import { Project } from '@/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  MoreVertical, 
  Calendar, 
  Users, 
  CheckCircle2,
  Clock,
  AlertCircle,
  Circle
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useProjects } from '@/hooks/useProjects';

interface ProjectCardProps {
  project: Project;
  onClick: () => void;
}

export const ProjectCard = ({ project, onClick }: ProjectCardProps) => {
  const { deleteProject } = useProjects();

  const getTaskStats = () => {
    const total = project.tasks.length;
    const completed = project.tasks.filter(t => t.status === 'done').length;
    const inProgress = project.tasks.filter(t => t.status === 'in-progress').length;
    const todo = project.tasks.filter(t => t.status === 'todo').length;
    
    return { total, completed, inProgress, todo };
  };

  const stats = getTaskStats();
  const progress = stats.total > 0 ? (stats.completed / stats.total) * 100 : 0;

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Are you sure you want to delete this project?')) {
      deleteProject(project.id);
    }
  };

  return (
    <Card 
      className="group cursor-pointer transition-all duration-300 hover:shadow-large hover:scale-105 glass border-white/20"
      onClick={onClick}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3">
            <div 
              className="w-3 h-8 rounded-full"
              style={{ backgroundColor: project.color }}
            />
            <div className="flex-1">
              <CardTitle className="text-lg group-hover:text-primary transition-colors">
                {project.name}
              </CardTitle>
              <CardDescription className="text-sm mt-1">
                {project.description}
              </CardDescription>
            </div>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
              <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Edit Project</DropdownMenuItem>
              <DropdownMenuItem>Manage Members</DropdownMenuItem>
              <DropdownMenuItem onClick={handleDelete} className="text-destructive">
                Delete Project
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Progress Bar */}
        {stats.total > 0 && (
          <div className="space-y-2">
            <div className="flex justify-between items-center text-sm">
              <span className="text-muted-foreground">Progress</span>
              <span className="font-medium">{Math.round(progress)}%</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className="h-2 rounded-full bg-gradient-primary transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        {/* Task Statistics */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-1">
              <CheckCircle2 className="w-4 h-4 text-success" />
              <span>{stats.completed}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Clock className="w-4 h-4 text-warning" />
              <span>{stats.inProgress}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Circle className="w-4 h-4 text-muted-foreground" />
              <span>{stats.todo}</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Users className="w-4 h-4" />
            <span>{project.members.length}</span>
          </div>
        </div>

        {/* Members Preview */}
        {project.members.length > 0 && (
          <div className="flex items-center space-x-2">
            <div className="flex -space-x-2">
              {project.members.slice(0, 3).map((member) => (
                <Avatar key={member.userId} className="w-8 h-8 border-2 border-background">
                  <AvatarImage src={member.user.avatar} />
                  <AvatarFallback className="text-xs bg-gradient-secondary text-white">
                    {member.user.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
              ))}
              {project.members.length > 3 && (
                <div className="w-8 h-8 rounded-full bg-muted border-2 border-background flex items-center justify-center">
                  <span className="text-xs text-muted-foreground">
                    +{project.members.length - 3}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Last Updated */}
        <div className="flex items-center space-x-2 text-xs text-muted-foreground">
          <Calendar className="w-3 h-3" />
          <span>Updated {project.updatedAt.toLocaleDateString()}</span>
        </div>
      </CardContent>
    </Card>
  );
};