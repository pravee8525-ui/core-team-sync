import React from 'react';
import { Task } from '@/types';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { useProjects } from '@/hooks/useProjects';
import { 
  Calendar, 
  MessageSquare, 
  MoreVertical,
  AlertCircle,
  Flag
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';

interface TaskCardProps {
  task: Task;
}

const PRIORITY_COLORS = {
  low: 'text-muted-foreground',
  medium: 'text-warning',
  high: 'text-accent',
  urgent: 'text-destructive',
};

const STATUS_COLORS = {
  todo: 'bg-muted',
  'in-progress': 'bg-warning',
  review: 'bg-accent',
  done: 'bg-success',
};

export const TaskCard = ({ task }: TaskCardProps) => {
  const { updateTask, deleteTask } = useProjects();

  const handleStatusChange = (newStatus: Task['status']) => {
    updateTask(task.id, { status: newStatus });
  };

  const handleDelete = () => {
    if (confirm('Are you sure you want to delete this task?')) {
      deleteTask(task.id);
    }
  };

  const isOverdue = task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'done';
  const isDueSoon = task.dueDate && 
    new Date(task.dueDate) <= new Date(Date.now() + 24 * 60 * 60 * 1000) && 
    task.status !== 'done';

  return (
    <Card className="group cursor-pointer transition-all duration-200 hover:shadow-medium border-l-4" 
          style={{ borderLeftColor: task.status === 'done' ? '#10B981' : '#E5E7EB' }}>
      <CardContent className="p-4 space-y-3">
        {/* Header */}
        <div className="flex items-start justify-between">
          <h4 className="font-medium text-sm leading-tight pr-2 group-hover:text-primary transition-colors">
            {task.title}
          </h4>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => handleStatusChange('todo')}>
                Move to To Do
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleStatusChange('in-progress')}>
                Move to In Progress
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleStatusChange('review')}>
                Move to Review
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleStatusChange('done')}>
                Move to Done
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Edit Task</DropdownMenuItem>
              <DropdownMenuItem onClick={handleDelete} className="text-destructive">
                Delete Task
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Description */}
        {task.description && (
          <p className="text-xs text-muted-foreground line-clamp-2">
            {task.description}
          </p>
        )}

        {/* Priority and Due Date */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {/* Priority */}
            <div className="flex items-center space-x-1">
              <Flag className={`w-3 h-3 ${PRIORITY_COLORS[task.priority]}`} />
              <span className={`text-xs capitalize ${PRIORITY_COLORS[task.priority]}`}>
                {task.priority}
              </span>
            </div>
          </div>

          {/* Due Date */}
          {task.dueDate && (
            <div className={`flex items-center space-x-1 text-xs ${
              isOverdue ? 'text-destructive' : isDueSoon ? 'text-warning' : 'text-muted-foreground'
            }`}>
              {isOverdue && <AlertCircle className="w-3 h-3" />}
              <Calendar className="w-3 h-3" />
              <span>{new Date(task.dueDate).toLocaleDateString()}</span>
            </div>
          )}
        </div>

        {/* Assignee */}
        {task.assignee && (
          <div className="flex items-center space-x-2">
            <Avatar className="w-6 h-6">
              <AvatarImage src={task.assignee.avatar} />
              <AvatarFallback className="text-xs bg-gradient-secondary text-white">
                {task.assignee.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <span className="text-xs text-muted-foreground">
              {task.assignee.name}
            </span>
          </div>
        )}

        {/* Status Badge */}
        <div className="flex items-center justify-between">
          <Badge 
            variant="secondary" 
            className={`text-xs ${STATUS_COLORS[task.status]} text-white`}
          >
            {task.status.replace('-', ' ')}
          </Badge>
          
          {/* Comments indicator (placeholder) */}
          <div className="flex items-center space-x-1 text-xs text-muted-foreground">
            <MessageSquare className="w-3 h-3" />
            <span>0</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};