import React, { useState } from 'react';
import { Task } from '@/types';
import { TaskCard } from './TaskCard';
import { CreateTaskModal } from './CreateTaskModal';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plus, MoreVertical } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface TaskBoardProps {
  tasks: Task[];
  projectId: string;
}

const TASK_STATUSES = [
  { id: 'todo', label: 'To Do', color: 'bg-muted' },
  { id: 'in-progress', label: 'In Progress', color: 'bg-warning' },
  { id: 'review', label: 'Review', color: 'bg-accent' },
  { id: 'done', label: 'Done', color: 'bg-success' },
] as const;

export const TaskBoard = ({ tasks, projectId }: TaskBoardProps) => {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState<string>('todo');

  const getTasksByStatus = (status: string) => {
    return tasks.filter(task => task.status === status);
  };

  const handleCreateTask = (status: string) => {
    setSelectedStatus(status);
    setIsCreateModalOpen(true);
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex-1 overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-full">
          {TASK_STATUSES.map((status) => {
            const statusTasks = getTasksByStatus(status.id);
            
            return (
              <Card key={status.id} className="flex flex-col h-full glass border-white/20">
                <CardHeader className="pb-3 flex-shrink-0">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${status.color}`} />
                      <CardTitle className="text-sm font-medium">
                        {status.label}
                      </CardTitle>
                      <Badge variant="secondary" className="text-xs">
                        {statusTasks.length}
                      </Badge>
                    </div>
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleCreateTask(status.id)}>
                          Add Task
                        </DropdownMenuItem>
                        <DropdownMenuItem>Clear All</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardHeader>

                <CardContent className="flex-1 overflow-y-auto custom-scrollbar space-y-3">
                  {statusTasks.map((task) => (
                    <TaskCard key={task.id} task={task} />
                  ))}
                  
                  {/* Add Task Button */}
                  <Button
                    variant="ghost"
                    className="w-full h-auto p-4 border-2 border-dashed border-border hover:border-primary hover:bg-primary/5 transition-all duration-200"
                    onClick={() => handleCreateTask(status.id)}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Task
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Create Task Modal */}
      <CreateTaskModal
        open={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        projectId={projectId}
        defaultStatus={selectedStatus as any}
      />
    </div>
  );
};